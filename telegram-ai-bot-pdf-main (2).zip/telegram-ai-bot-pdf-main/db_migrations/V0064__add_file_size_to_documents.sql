ALTER TABLE t_p56134400_telegram_ai_bot_pdf.tenant_documents 
ADD COLUMN IF NOT EXISTS file_size_bytes BIGINT;