ALTER TABLE t_p56134400_telegram_ai_bot_pdf.widget_settings 
ADD COLUMN button_icon VARCHAR(50) DEFAULT 'MessageCircle';