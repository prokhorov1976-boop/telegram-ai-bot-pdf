UPDATE t_p56134400_telegram_ai_bot_pdf.page_settings 
SET setting_value = 'https://max.ru/u/f9LHodD0cOIrknUlAYx1LxuVyfuHRhIq-OHhkpPMbwJ_WcjW4dhTFpEEez0', 
    updated_at = NOW() 
WHERE setting_key = 'footer_link';