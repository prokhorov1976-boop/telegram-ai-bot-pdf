ALTER TABLE t_p56134400_telegram_ai_bot_pdf.quality_gate_logs 
ADD COLUMN IF NOT EXISTS top_k_used INTEGER DEFAULT 3;